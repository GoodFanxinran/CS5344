
import math
import os
import re
import sys
from pyspark import SparkContext, SparkConf

conf = SparkConf()
sc = SparkContext(conf=conf)
"""
step1
"""
stopword = sc.textFile(sys.argv[2]).collect()
query = sc.textFile(sys.argv[3]).flatMap(lambda l: re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', l)).filter(lambda l1: l1 is not "").collect()


# read datafiles
all_documents = sc.wholeTextFiles(sys.argv[1])
doc_num = all_documents.count() 


def process_one(f):
    a, b = os.path.split(f[0])
    v = re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', f[1])
    lst = []
    for w in v:
        lst.append(((w.lower(), b), 1))
    return lst


def process_two(data):
    w = re.sub('[^A-Za-z0-9]+', '', data[0][0])
    return ((w, data[0][1]), data[1])



w_d_nw = all_documents.flatMap(process_one).filter(lambda x: x[0][0] not in stopword) \
.map(process_two).filter(lambda a: a[0][0] is not "" and a[0][0] not in stopword).reduceByKey(lambda n1, n2: n1 + n2)  # get: ((w, d), nw)


w_d = w_d_nw.map(lambda a: a[0])  # get: (w, d)
w_nd = w_d.groupByKey().map(lambda a: (a[0], len(a[1])))   

w_dnd = w_d.join(w_nd).map(lambda a: ((a[0], a[1][0]), a[1][1]))  
w_d_nwnd = w_d_nw.join(w_dnd)  # get: ((w, d), (nw, nd))  



""" 
step2: Compute TF-IDF

"""
def tf_idf(n, data):
    a,b = data[0],data[1]
    tf_idf = (1 + math.log10(b[0])) * math.log10(n / b[1])
    return a[1], (a[0], tf_idf)

#calculate tf-idf
tfidf = w_d_nwnd.map(lambda t: tf_idf(doc_num, t))  
d_l = tfidf.map(lambda a: (a[0], a[1][1] * a[1][1])).reduceByKey(lambda n1, n2: (n1 + n2)).map(lambda x: (x[0], math.sqrt(x[1]))) 


"""
step3: Compute normalized TF-IDF

"""
dw_norm = tfidf.join(d_l).map(lambda a: (a[0], (a[1][0][0], a[1][0][1] / a[1][1])))  
w_d_norm = dw_norm.map(lambda a : (a[1][0], (a[0], a[1][1]))) 


def cal_query(data, lens):
    if data[0] in query:
        return data[0], 1/lens
    else:
        return data[0], 0

"""
step4: Compute the relevance
"""
q_c = w_nd.filter(lambda x: x[0] in query)
ql = math.sqrt(q_c.count())  
normquery = w_nd.map(lambda l: cal_query(l, ql))
# calculate (doc, relevance)
relevance = w_d_norm.join(normquery).map(lambda t: (t[1][0][0], t[1][0][1] * t[1][1])).reduceByKey(lambda n1, n2: n1 + n2)   


"""
 step5: Sort and get top-10 documents.
"""
top_10 = relevance.sortBy(lambda x: x[1], ascending=False).take(10)
rdd_10 = sc.parallelize(top_10)
rdd_10.map(lambda x: "<{}> <{}>".format(x[0], x[1])).coalesce(1).saveAsTextFile(sys.argv[4])

"""step6: For each of the top-10 document, compute the relevance of each sentence w.r.t the query. A sentence is delimited by a full-stop."""



"""step7: Output the most relevant sentence for each of the top-10 document."""

sc.stop()
