# _*_ coding: utf-8 -*
from pyspark import SparkContext, SparkConf, SparkFiles
from os import listdir
import os
import sys
import math
import re
import string
import math
import numpy as np



conf = SparkConf()
sc = SparkContext(conf=conf)
accum = sc.accumulator(0)

datafiles_folder = sys.argv[1]
stopwords_file_path = sys.argv[2]
query_file_path = sys.argv[3]
outfile_path = sys.argv[4]

def remove_stopwords(line):
	with open('stopwords.txt','r') as f:
		stopwords = [word.rstrip('\n') for word in f.readlines()]
	return " ".join([x for x in line.split(" ") if x not in stopwords])


def tf_idf_calculation(n, data):
	k = data[0]
	v = data[1]
	tf_idf = tf_idf_formula(v[0], v[1], n)
	return k[1], (k[0], tf_idf)


def tf_idf_formula(tf, df, n):
	return (1 + math.log10(tf)) * math.log10(n / df)


def flat_n_document_v2(data):
	k = data[0]
	head, tail = os.path.split(k)
	# v = re.split(r'[^\w]+', data[1])
	v = re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', data[1])

	vl = []
	for w in v:
		lower_w = w.lower()
		vl.append(((lower_w, tail), 1))

	return vl


def flat_n_document_v3(data):
	w = data[0][0]
	doc = data[0][1]
	numofwords = data[1]

	w2 = re.sub('[^A-Za-z0-9]+', '', w)

	return ((w2, doc), numofwords)


def valid_word_in_query(data, query_len):
	k = data[0]
	if k in query_rdd_collection:
		return k, 1/query_len
	else:
		return k, 0

"""
Step 1. Compute term frequency (TF) of every word in a document.
"""
directory = ",".join(sorted([os.path.join(datafiles_folder, x) for x in os.listdir(datafiles_folder) if x != ".DS_Store"]))
datafile_rdd = sc.textFile(directory)
d = (datafile_rdd.map(lambda x: x.lower()).map(remove_stopwords))

# TF is the count of the word in a document
"""
• Flatmap splits all file content into words, and generate into a pair with format RDD ((word, doc), 1)
• Filter removes item which has the word is in listed in stop word list
• Map removes some special symbols such as : !,’,-, [, ] ...
• Filter removes item which has the word is empty string or listed in stop word list.
• ReduceByKey computes number of words in a document, then RDD ((word,doc), 1) is transformed to RDD ((word, doc), numofwords).
"""

query_rdd = sc.textFile(query_file_path)
query_rdd_collection = query_rdd.flatMap(lambda l: re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', l)).filter(lambda l1: l1 is not "").collect()


stopword_rdd = sc.textFile(stopwords_file_path)
stopword_rdd_collection = stopword_rdd.collect()

n_document = sc.wholeTextFiles(datafiles_folder)
# get numofdoc
num_of_doc = n_document.count()
# get ((word, doc), numofwords)
n_document_wd_n = n_document.flatMap(flat_n_document_v2).filter(lambda w1: w1[0][0] not in stopword_rdd_collection).map(flat_n_document_v3) \
.filter(lambda w2: w2[0][0] is not "" and w2[0][0] not in stopword_rdd_collection).reduceByKey(lambda v1, v2: v1 + v2)  # ((w,d), n)


# DF is the count of documents having the word
"""
• Map transform RDD((word,doc), numofwords)) into RDD(word, doc) (1)
• GroupByKey creates document list for a word RDD (word, [doc1,doc2...])
• Map counts number of documents for a word and transform into RDD (word, numofdocs) (2)
"""
# get (word, doc)
n_document_w_d = n_document_wd_n.map(lambda data2: data2[0])  # get (w,d)

# get (word, numofdocs)
n_document_w_m = n_document_w_d.groupByKey().map(lambda data3: (data3[0], len(data3[1])))  # get (w,m)

# get ((word, doc), numofdocs)
n_document_wd_n = n_document_w_d.join(n_document_w_m).map(lambda t: ((t[0], t[1][0]), t[1][1]))  # ((w,d), m)

# get ((word, doc), (numofwords, numofdocs))
n_document_wd_nm = n_document_wd_n.join(n_document_wd_n)  # ((w,d), (n,m))

"""
    n_document_wd_n = whole_documents.flatMap(flat_n_document_v2) \
        .filter(lambda x: x[0][0] not in stopword_rdd_collection) \
        .map(flat_n_document_v3) \
        .filter(lambda y: y[0][0] is not "" and y[0][0] not in stopword_rdd_collection) \
        .reduceByKey(lambda a, b: a + b)  # get: ((word, doc), numofwords)
     

    n_document_w_d = n_document_wd_n.map(lambda x: x[0])  # get: (word, doc)
    n_document_w_m = n_document_w_d.groupByKey().map(lambda x: (x[0], len(x[1])))  # get: (word, numofdocs)  (w,m) 

    n_document_wd_n = n_document_w_d.join(n_document_w_m).map(lambda t: ((t[0], t[1][0]), t[1][1]))  # get ((word, doc), numofdocs) ((w,d), m)
    n_document_wd_nm = n_document_wd_n.join(n_document_wd_n)  # get: ((word, doc), (numofwords, numofdocs)) ((w,d), (n,m)) 



    n_document_d_wtf = n_document_wd_nm.map(lambda t: tf_idf_calculation(doc_num, t))  # (d,(w,tf))

"""



"""


Step 2. Compute TF-IDF of every word w.r.t a document.
Use key-value pair RDD and the groupByKey() API for this step.
• From (1) and (2), join RDD (word, doc) and RDD (word, numofdocs) to create RDD (word, (doc, numofdocs))
• Map transform RDD (word, (doc, numofdocs)) to RDD ((word, doc), numofdocs)
• Join RDD ((word, doc), numofwords) and RDD ((word, doc), numofdocs) to create RDD ((word,doc), (numofwords, numofdocs))
• Map calculate TF-IDF for words of documents in RDD ((word, doc), (numofwords, numofdocs)) with the number_of_documents.
• we get RDD (doc, (word ,tf-idf))
"""

# get (doc, (word, tf-idf))
n_document_d_wtf = n_document_wd_nm.map(lambda t: tf_idf_calculation(num_of_doc, t))  # (d,(w,tf))

"""
Step 3. Compute normalized TF-IDF of every word w.r.t. a document.
If the TF-IDF value of word1 in doc1 is t1 and the sum of squares of the TF-IDF of all the words in doc1 is S, then the normalized TF-IDF value of word1 is.
• Map transforms (doc, (word ,tf-idf)) to (doc, tf-idf * tf-idf)
• ReduceByKey sums all square of tf-idf for a document, then we get RDD (doc, sum_of_square_of_tf-idf)
• Map gets square root of sum_of_square_of_tf-idf which is also a length of doc vector , then RDD (doc, ||doc||) is created
• Join (doc, (word ,tf-idf)) and (doc, ||doc||) to create (doc, ((word ,tf-idf), ||doc||))
• Map normalizes TF-IDF and transform to (doc, (word, norm_tf-idf))
"""
# get (doc, ||doc||)
n_document_d_l = n_document_d_wtf.map(lambda t1: (t1[0], t1[1][1] * t1[1][1])).reduceByKey(lambda n1, n2: (n1 + n2)).map(lambda t2: (t2[0], math.sqrt(t2[1])))  # (d,l)

# get (doc, ((word ,tf-idf), ||doc||)
n_document_d_wtf_l = n_document_d_wtf.join(n_document_d_l)  # (d, ((w,tf), l))

# get (doc, (word, norm_tf-idf))
n_document_d_wnorm = n_document_d_wtf_l.map(lambda t: (t[0], (t[1][0][0], t[1][0][1] / t[1][1])))  # (d,(w,norm))

# get (word, (doc, d_norm))
n_document_w_dnorm = n_document_d_wnorm.map(lambda t : (t[1][0], (t[0], t[1][1]))) # (w,(d,d_norm))

"""
From RDD (word, numofdocs) , applying filter to select words available in querystring. 
The length of query vector ||V|| is a square root of number of wordswhich are available in query string
From RDD (word, numofdocs) again, applying map to normalize and transform RDD (word, numofdocs) into RDD (word , b/||V||) in which b is 1 
if the word is available in query string, otherwise b is 0. 
Finally, we obtain a normalized query vector RDD (word , norm_query_item)
"""
# find words in query.
n_query_w_n = n_document_w_m.filter(lambda l: l[0] in query_rdd_collection)  # find words in query, if it is found, then it is asigned to 1

# get (word , norm_query_item)
n_query_w_nl = n_document_w_m.map(lambda l: valid_word_in_query(l, math.sqrt(n_query_w_n.count())))  # calculate magnitude of query (w, q_norm))


"""
Step 4. Compute the relevance of each document w.r.t a query.
• Join RDD (word, (doc, norm_tf-idf)) and RDD (word , norm_query_item) to create RDD (word, ((doc, norm_tf-idf,), norm_query_item))
• Map multiplies norm_tf-idf and norm_query_item and transforms to RDD (doc , norm_tf-idf * norm_query_item)
• ReduceByKey sums up the multiplication results for each document and create RDD (doc, relevant_score). 
Because all doc vectors and query vector are normalized, the sum is also a result of Cosine Similarity or relevant score between a document and query
"""

# get (word, ((doc, norm_tf-idf,), norm_query_item))
n_document_query = n_document_w_dnorm.join(n_query_w_nl)  # (w,((d, d_norm), q_norm))

# get (doc , norm_tf-idf * norm_query_item)
n_document_query2 = n_document_query.map(lambda t: (t[1][0][0], t[1][0][1] * t[1][1]))  # (d, product)

# get (doc, relevant_score)
n_document_query3 = n_document_query2.reduceByKey(lambda v1, v2: v1 + v2)  # (d,sum of product)


"""
Step 5. Sort and get top-10 documents.
Sort RDD (doc, relevant_score) by relevant_score and display top 10 documents have highest relevant score
"""
n_document_query_relevant_sorted = n_document_query3.sortBy(lambda e: e[1], ascending=False)
top_10_document_relevant = n_document_query_relevant_sorted.take(10)

rdd_10 = sc.parallelize(top_10_document_relevant)
rdd_10.map(lambda l: "<{}> <{}>".format(l[0], l[1])).coalesce(1).saveAsTextFile(sys.argv[4])


"""
Step 6. For each of the top-10 document, compute the relevance of each sentence w.r.t the query. A sentence is delimited by a full-stop.
"""
    word_doc_numword = whole_documents.flatMap(clean_data1) \
        .filter(lambda x: x[0][0] not in stopword_rdd_collection) \
        .map(clean_data2) \
        .filter(lambda y: y[0][0] is not "" and y[0][0] not in stopword_rdd_collection) \
        .reduceByKey(lambda a, b: a + b)  # get: ((word, doc), numofwords)
     

    word_doc = word_doc_numword.map(lambda x: x[0])  # get: (word, doc)
    word_numdoc = word_doc.groupByKey().map(lambda x: (x[0], len(x[1])))  # get: (word, numofdocs)  

    word_doc_numdoc = word_doc.join(word_numdoc).map(lambda t: ((t[0], t[1][0]), t[1][1]))  # get ((word, doc), numofdocs)  
    word_doc_numword_numdoc = word_doc_numword.join(word_doc_numdoc)  # get: ((word, doc), (numofwords, numofdocs))  


    # step2: Compute TF-IDF of every word w.r.t a document.
    doc_word_tfidf = word_doc_numword_numdoc.map(lambda t: tf_idf_calculation(doc_num, t))  #get: (doc, (word, tf-idf))  


    doc_sum_square_tfidf = doc_word_tfidf.map(lambda x: (x[0], x[1][1] * x[1][1])).reduceByKey(lambda a, b: (a + b)) # get: (doc, sum_of_square_of_tf-idf)
    doc_doclen = doc_sum_square_tfidf.map(lambda x: (x[0], math.sqrt(x[1])))  # get (doc, ||doc||) 

    doc_word_tfidf_doclen = doc_word_tfidf.join(doc_doclen)  # get: (doc, ((word ,tf-idf), ||doc||)
    # step3: Compute normalized TF-IDF of every word w.r.t. a document.
    doc_word_normtfidf = doc_word_tfidf_doclen.map(lambda t: (t[0], (t[1][0][0], t[1][0][1] / t[1][1])))  # get: (doc, (word, norm_tf-idf))  
    word_doc_normtfidf = doc_word_normtfidf.map(lambda x : (x[1][0], (x[0], x[1][1]))) # get: (word, (doc, norm_tf-idf))   
    


    # step4: Compute the relevance of each document w.r.t a query.
    query_filter = word_numdoc.filter(lambda x: x[0] in query_rdd_collection)  #  select words available in querystring
    query_len = math.sqrt(query_filter.count())  

    word_normquery = word_numdoc.map(lambda l: valid_word_in_query(l, query_len))  # get (word , norm_query)  


    
    word_doc_normtfidf_normquery = word_doc_normtfidf.join(word_normquery)  # get (word, ((doc, norm_tf-idf,), norm_query))  
    doc_multiplies = word_doc_normtfidf_normquery.map(lambda t: (t[1][0][0], t[1][0][1] * t[1][1]))  # get: (doc , norm_tf-idf * norm_query)
    doc_relevant_score = doc_multiplies.reduceByKey(lambda a, b: a + b)  # get: (doc, relevant_score)   


    # step5: Sort and get top-10 documents.
    doc_relevant_score_sorted = doc_relevant_score.sortBy(lambda x: x[1], ascending=False) # sort
    top_10_document_relevant = doc_relevant_score_sorted.take(10)

    rdd_top_10 = sc.parallelize(top_10_document_relevant)
    rdd_top_10.map(lambda x: "<{}> <{}>".format(x[0], x[1])).coalesce(1).saveAsTextFile(outfile_path)


"""
Step 7. Output the most relevant sentence for each of the top-10 document.
"""



sc.stop()


