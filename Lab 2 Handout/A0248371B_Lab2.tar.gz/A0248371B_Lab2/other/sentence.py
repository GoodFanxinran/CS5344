    


    sentence_doc = doc_relevant_score_sorted.flatMap(lambda l: re.split('.', l)) 



    word_doc_numword = whole_documents.flatMap(clean_data1) \
        .filter(lambda x: x[0][0] not in stopword_rdd_collection) \
        .map(clean_data2) \
        .filter(lambda y: y[0][0] is not "" and y[0][0] not in stopword_rdd_collection) \
        .reduceByKey(lambda a, b: a + b)  # get: ((word, doc), numofwords)
     

    word_doc = word_doc_numword.map(lambda x: x[0])  # get: (word, doc)
    word_numdoc = word_doc.groupByKey().map(lambda x: (x[0], len(x[1])))  # get: (word, numofdocs)  

    word_doc_numdoc = word_doc.join(word_numdoc).map(lambda t: ((t[0], t[1][0]), t[1][1]))  # get ((word, doc), numofdocs)  
    word_doc_numword_numdoc = word_doc_numword.join(word_doc_numdoc)  # get: ((word, doc), (numofwords, numofdocs))  


    # step2: Compute TF-IDF of every word w.r.t a document.
    doc_word_tfidf = word_doc_numword_numdoc.map(lambda t: tf_idf_calculation(doc_num, t))  #get: (doc, (word, tf-idf))  


    doc_sum_square_tfidf = doc_word_tfidf.map(lambda x: (x[0], x[1][1] * x[1][1])).reduceByKey(lambda a, b: (a + b)) # get: (doc, sum_of_square_of_tf-idf)
    doc_doclen = doc_sum_square_tfidf.map(lambda x: (x[0], math.sqrt(x[1])))  # get (doc, ||doc||) 

    doc_word_tfidf_doclen = doc_word_tfidf.join(doc_doclen)  # get: (doc, ((word ,tf-idf), ||doc||)
    # step3: Compute normalized TF-IDF of every word w.r.t. a document.
    doc_word_normtfidf = doc_word_tfidf_doclen.map(lambda t: (t[0], (t[1][0][0], t[1][0][1] / t[1][1])))  # get: (doc, (word, norm_tf-idf))  
    word_doc_normtfidf = doc_word_normtfidf.map(lambda x : (x[1][0], (x[0], x[1][1]))) # get: (word, (doc, norm_tf-idf))   
    


    # step4: Compute the relevance of each document w.r.t a query.
    query_filter = word_numdoc.filter(lambda x: x[0] in query_rdd_collection)  #  select words available in querystring
    query_len = math.sqrt(query_filter.count())  

    word_normquery = word_numdoc.map(lambda l: valid_word_in_query(l, query_len))  # get (word , norm_query)  


    
    word_doc_normtfidf_normquery = word_doc_normtfidf.join(word_normquery)  # get (word, ((doc, norm_tf-idf,), norm_query))  
    doc_multiplies = word_doc_normtfidf_normquery.map(lambda t: (t[1][0][0], t[1][0][1] * t[1][1]))  # get: (doc , norm_tf-idf * norm_query)
    doc_relevant_score = doc_multiplies.reduceByKey(lambda a, b: a + b)  # get: (doc, relevant_score)   


    # step5: Sort and get top-10 documents.
    doc_relevant_score_sorted = doc_relevant_score.sortBy(lambda x: x[1], ascending=False) # sort
    top_10_document_relevant = doc_relevant_score_sorted.take(10)

    rdd_top_10 = sc.parallelize(top_10_document_relevant)
    rdd_top_10.map(lambda x: "<{}> <{}>".format(x[0], x[1])).coalesce(1).saveAsTextFile(outfile_path)

