import math
import os
import re
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import numpy as np
from pyspark import SparkContext, SparkConf

datafiles_folder = sys.argv[1]
stopwords_file_path = sys.argv[2]
query_file_path = sys.argv[3]
outfile_path = sys.argv[4]

def remove_stopwords(line):
    with open('stopwords.txt','r') as f:
        stopwords = [word.rstrip('\n') for word in f.readlines()]
    return " ".join([x for x in line.split(" ") if x not in stopwords])


def tf_idf_calculation(n, data):
    k,v = data[0],data[1]
    tf,df = v[0],v[1]
    tf_idf = (1 + math.log10(tf)) * math.log10(n / df)
    return k[1], (k[0], tf_idf)


def valid_word_in_query(data, query_len):
    if data[0] in query_rdd_collection:
        return data[0], 1/query_len
    else:
        return data[0], 0


def clean_data1(data):
    k = data[0]
    head, tail = os.path.split(k)
    v = re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', data[1])
    vl = []
    for w in v:
        vl.append(((w.lower(), tail), 1))
    return vl


def clean_data2(data):
    w = data[0][0]
    doc = data[0][1]
    numofwords = data[1]
    w2 = re.sub('[^A-Za-z0-9]+', '', w)
    return ((w2, doc), numofwords)


def split_data(data):
    vl = []
    v = re.split(r'[.!?]', data)
    for w in v:
        vl.append(w)
    return vl

def tf(document):
    word_count = dict()
    for item in document:
        word = item[0]
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1
    for (word, count) in [(k, word_count[k]) for k in word_count]:
        yield (word, count)


def df(document):
    document_count = dict()
    for word in document:
        if word not in document_count.keys():
            document_count[word] = 1
            yield (word, 1)

def tfidf(document,df,N):
    document = list(document)
    tfidf_dict = dict.fromkeys(df.keys(), 0)
    for tf_element in document:
        word, tf = tf_element
        tfidf_dict[word] = (1+(np.log10(tf))) * np.log10(N / df[word])
    for word, tfidf in tfidf_dict.items():
        yield (word, tfidf)


def tfidf_norm(document):
    document = list(document)
    S=0
    for word, tfidf in document:
        S  += tfidf**2
    if(S!=0):
        for tfidf_element in document:
            word, tfidf = tfidf_element
            yield (word, tfidf / np.sqrt(S))
    else:
        for tfidf_element in document:
            word, tfidf = tfidf_element
            yield (word, 1000)

def cos_sim(query, norm_tfidf_matrix):
    return np.dot(query, norm_tfidf_matrix) / (np.linalg.norm(query) * np.linalg.norm(norm_tfidf_matrix))


def clean_data(data):
    vl = []
    re.sub('http://\S+|https://\S+|www\S+', '', data)
    v = re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)|[-]', data)
    for w in v:
        lower_w = w.lower()
        w2 = re.sub('[^A-Za-z0-9]+', '', lower_w)
        vl.append(w2)
    return vl


if __name__ == "__main__":
    conf = SparkConf()
    sc = SparkContext(conf=conf)
    accum = sc.accumulator(0)
    # step1: Compute term frequency (TF) of every word in a document.
    query_rdd = sc.textFile(query_file_path)
    query_rdd_collection = query_rdd.flatMap(lambda l: re.split(r'\s|(?<!\d)[,.]|[,.](?!\d)', l)).filter(lambda l1: l1 is not "").collect()


    stopword_rdd = sc.textFile(stopwords_file_path)
    stopword_rdd_collection = stopword_rdd.collect()

    whole_documents = sc.wholeTextFiles(datafiles_folder) # read all datafiles
    doc_num = whole_documents.count() # get num of doc -> doc_num

    word_doc_numword = whole_documents.flatMap(clean_data1) \
        .filter(lambda x: x[0][0] not in stopword_rdd_collection) \
        .map(clean_data2) \
        .filter(lambda y: y[0][0] is not "" and y[0][0] not in stopword_rdd_collection) \
        .reduceByKey(lambda a, b: a + b)  # get: ((word, doc), numofwords)
     

    word_doc = word_doc_numword.map(lambda x: x[0])  # get: (word, doc)
    word_numdoc = word_doc.groupByKey().map(lambda x: (x[0], len(x[1])))  # get: (word, numofdocs)  

    word_doc_numdoc = word_doc.join(word_numdoc).map(lambda t: ((t[0], t[1][0]), t[1][1]))  # get ((word, doc), numofdocs)  
    word_doc_numword_numdoc = word_doc_numword.join(word_doc_numdoc)  # get: ((word, doc), (numofwords, numofdocs))  


    # step2: Compute TF-IDF of every word w.r.t a document.
    doc_word_tfidf = word_doc_numword_numdoc.map(lambda t: tf_idf_calculation(doc_num, t))  #get: (doc, (word, tf-idf))  


    doc_sum_square_tfidf = doc_word_tfidf.map(lambda x: (x[0], x[1][1] * x[1][1])).reduceByKey(lambda a, b: (a + b)) # get: (doc, sum_of_square_of_tf-idf)
    doc_doclen = doc_sum_square_tfidf.map(lambda x: (x[0], math.sqrt(x[1])))  # get (doc, ||doc||) 

    doc_word_tfidf_doclen = doc_word_tfidf.join(doc_doclen)  # get: (doc, ((word ,tf-idf), ||doc||)
    # step3: Compute normalized TF-IDF of every word w.r.t. a document.
    doc_word_normtfidf = doc_word_tfidf_doclen.map(lambda t: (t[0], (t[1][0][0], t[1][0][1] / t[1][1])))  # get: (doc, (word, norm_tf-idf))  
    word_doc_normtfidf = doc_word_normtfidf.map(lambda x : (x[1][0], (x[0], x[1][1]))) # get: (word, (doc, norm_tf-idf))   
    


    # step4: Compute the relevance of each document w.r.t a query.
    query_filter = word_numdoc.filter(lambda x: x[0] in query_rdd_collection)  #  select words available in querystring
    query_len = math.sqrt(query_filter.count())  

    word_normquery = word_numdoc.map(lambda l: valid_word_in_query(l, query_len))  # get (word , norm_query)  

    
    word_doc_normtfidf_normquery = word_doc_normtfidf.join(word_normquery)  # get (word, ((doc, norm_tf-idf,), norm_query))  
    doc_multiplies = word_doc_normtfidf_normquery.map(lambda t: (t[1][0][0], t[1][0][1] * t[1][1]))  # get: (doc , norm_tf-idf * norm_query)
    doc_relevant_score = doc_multiplies.reduceByKey(lambda a, b: a + b)  # get: (doc, relevant_score)   


    # step5: Sort and get top-10 documents.
    doc_relevant_score_sorted = doc_relevant_score.sortBy(lambda x: x[1], ascending=False) # sort
    top_10_document_relevant = doc_relevant_score_sorted.take(10)
    # print("top_10_document_relevant:",top_10_document_relevant)
    rdd_top_10 = sc.parallelize(top_10_document_relevant)
    # rdd_top_10.map(lambda x: "<{}> <{}>".format(x[0], x[1])).coalesce(1).saveAsTextFile(outfile_path)



    # step6: For each of the top-10 document, compute the relevance of each sentence w.r.t the query. A sentence is delimited by a full-stop.
    # step7: Output the most relevant sentence for each of the top-10 document.
    top10_doc = []
    for doc,relevance_doc in top_10_document_relevant:
        top10_doc.append([doc,relevance_doc])
    
    top_10_new = []
    for i in range(10):
        doci = top10_doc[i][0]
        relevance_doc = top10_doc[i][1]
        directory = os.path.join(datafiles_folder, str(doci))
        files = sc.textFile(directory)
        doc_con = files.flatMap(lambda x: split_data(x))
        sentence_list = doc_con.collect()
        sen_list = []
        for sen in sentence_list:
            if(re.match(r'[^A-Za-z0-9]+',sen)):
                pass
            else:
                sen_list.append(sen)

        
        sentence_rdd = sc.parallelize(sen_list,len(sen_list))
        new_data = sentence_rdd.flatMap(clean_data).filter(lambda x: x!="" and x not in stopword_rdd_collection)
        TF = (new_data.map(lambda x: (x, 1)).mapPartitions(lambda x: tf(x)))
        DF = dict(new_data.mapPartitions(lambda x: df(x)).reduceByKey(lambda a, b: a + b).collect())
        tf_idf = (TF.mapPartitions(lambda x: tfidf(x, DF, len(sen_list))))
        tf_idf_norm = dict(tf_idf.mapPartitions(lambda x: tfidf_norm(x)).groupByKey().mapValues(list).collect())

        
        matrix = np.array(list(tf_idf_norm.values()))
        listi = dict.fromkeys(list(tf_idf_norm.keys()), 0)
        for q in query_rdd_collection:
            if q in listi:
                listi[q] = 1
        vetor = np.array(list(listi.values()))
        ans = []
        for n in range(len(sen_list)):
            ans.append(cos_sim(vetor, [i[n] for i in matrix]))
        
        score = sorted([(doc, sim) for doc, sim in enumerate(ans)], key=lambda x: x[1], reverse=True)
    
        one = []
        top_sen_id = score[0][0]
        top_sen_re = score[0][1]
        one.append(doci)
        one.append(str(relevance_doc))
        one.append(sen_list[top_sen_id])
        one.append(str(top_sen_re))
        top_10_new.append(one)

    print("top_10_new",top_10_new)
    top_file = open('out/top10.txt','w')
    for i in top_10_new:
        stri = " ".join(i).encode('utf-8')
        top_file.write(stri+'\n')
    top_file.close()

    sc.stop()
